<?php

namespace LaravelPayfort\Exceptions;


class PayfortException extends \Exception
{

}