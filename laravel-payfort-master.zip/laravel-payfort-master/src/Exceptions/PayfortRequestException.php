<?php

namespace LaravelPayfort\Exceptions;


class PayfortRequestException extends PayfortException
{

}